import { TdUploadProps } from './type';
declare const props: TdUploadProps;
export default props;
