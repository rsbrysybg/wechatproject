declare const _default: {
    prefix: string;
};
export default _default;
export declare const prefix = "t";
