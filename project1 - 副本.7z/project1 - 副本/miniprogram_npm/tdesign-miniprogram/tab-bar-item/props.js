const props = {
    badgeProps: {
        type: Object,
    },
    icon: {
        type: null,
    },
    subTabBar: {
        type: Array,
    },
    value: {
        type: null,
    },
};
export default props;
