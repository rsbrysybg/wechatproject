import { TdSwiperProps } from './type';
declare const props: TdSwiperProps;
export default props;
