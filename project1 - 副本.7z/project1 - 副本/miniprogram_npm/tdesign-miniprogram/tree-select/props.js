const props = {
    height: {
        type: null,
        value: 336,
    },
    keys: {
        type: Object,
    },
    multiple: {
        type: Boolean,
        value: false,
    },
    options: {
        type: Array,
        value: [],
    },
    value: {
        type: null,
        value: null,
    },
    defaultValue: {
        type: null,
    },
};
export default props;
