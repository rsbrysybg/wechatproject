import { TdSideBarProps } from './type';
declare const props: TdSideBarProps;
export default props;
