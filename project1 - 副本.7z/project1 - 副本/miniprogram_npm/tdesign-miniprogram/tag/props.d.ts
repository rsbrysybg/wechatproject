import { TdTagProps } from './type';
declare const props: TdTagProps;
export default props;
