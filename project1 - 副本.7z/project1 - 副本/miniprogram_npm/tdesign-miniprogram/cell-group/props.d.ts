import { TdCellGroupProps } from './type';
declare const props: TdCellGroupProps;
export default props;
