import { TdPopupProps } from './type';
declare const props: TdPopupProps;
export default props;
