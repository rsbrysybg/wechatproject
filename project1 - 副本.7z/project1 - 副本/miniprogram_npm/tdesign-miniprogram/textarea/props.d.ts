import { TdTextareaProps } from './type';
declare const props: TdTextareaProps;
export default props;
