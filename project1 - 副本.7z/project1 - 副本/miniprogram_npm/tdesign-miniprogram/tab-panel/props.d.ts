import { TdTabPanelProps } from './type';
declare const props: TdTabPanelProps;
export default props;
