import { TdRadioGroupProps } from './type';
declare const props: TdRadioGroupProps;
export default props;
