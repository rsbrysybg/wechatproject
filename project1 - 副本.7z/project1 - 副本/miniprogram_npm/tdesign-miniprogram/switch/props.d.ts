import { TdSwitchProps } from './type';
declare const props: TdSwitchProps;
export default props;
