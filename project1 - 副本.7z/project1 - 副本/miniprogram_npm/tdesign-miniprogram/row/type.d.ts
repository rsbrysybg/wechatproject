export interface TdRowProps {
    gutter?: {
        type: null;
        value?: string | number;
    };
}
