const props = {
    gutter: {
        type: null,
    },
};
export default props;
