import { TdRowProps } from './type';
declare const props: TdRowProps;
export default props;
