export declare const trimSingleValue: (value: any, min: number, max: number) => number;
export declare const trimValue: (value: number | number[], props: any) => number | number[];
